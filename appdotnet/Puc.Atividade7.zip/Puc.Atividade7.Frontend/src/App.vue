<template>
  <div id="app">
    <h1>Cabecalho</h1>
    <router-view/>
  </div>
</template>

<script>
export default {
}
</script>

<style>
</style>
